# Standard Libraries
import os
import re

# Data Manipulation and Analysis
import pandas as pd
import numpy as np

# Machine Learning and Model Evaluation
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix, precision_recall_curve
from sklearn.utils import resample

# Visualization
import matplotlib.pyplot as plt
import seaborn as sns

# Audio Processing
import librosa
import librosa.display
import resampy




    

# Function to extract MFCC features from audio files
def extract_mfcc_features(file_path):
    try:
        # Load the audio file
        audio, sample_rate = librosa.load(file_path, res_type='kaiser_fast')
        print(f"Loaded audio: {file_path}, Sample rate: {sample_rate}, Audio length: {len(audio)}")

        # Extract MFCC features
        mfccs = librosa.feature.mfcc(y=audio, sr=sample_rate, n_mfcc=13)
        print(f"MFCC shape: {mfccs.shape}")

        # Return the mean of the MFCC features
        mfccs_mean = np.mean(mfccs.T, axis=0)
        return mfccs_mean
    except Exception as e:
        print(f"Error processing {file_path}: {e}")
        return None

# Paths to the audio dataset and labels CSV
audio_folder = r"C:\Users\growt\Desktop\ML\archive\TRAIN"  # Folder containing the audio files
audio_labels_file = r"C:\Users\growt\Desktop\ML\archive\TRAIN.csv"  # CSV file with labels

# Load the labels CSV
audio_df = pd.read_csv(audio_labels_file)

# Verify the CSV structure
if 'Filename' not in audio_df.columns or 'Class' not in audio_df.columns:
    raise ValueError("CSV file must contain 'Filename' and 'Class' columns")

# Add file paths to the DataFrame
audio_df['file_path'] = audio_df['Filename'].apply(lambda x: os.path.join(audio_folder, x))

# Verify file existence
audio_df['exists'] = audio_df['file_path'].apply(os.path.exists)
missing_files = audio_df[~audio_df['exists']]
if not missing_files.empty:
    print("Missing files detected:")
    print(missing_files)
    exit("Ensure all files are present before proceeding.")

# Extract features and labels
features = []
labels = []

for index, row in audio_df.iterrows():
    file_path = row['file_path']
    label = row['Class']
    if os.path.exists(file_path):
        print(f"Processing file: {file_path}")
        mfcc = extract_mfcc_features(file_path)
        if mfcc is not None:
            features.append(mfcc)
            labels.append(label)
    else:
        print(f"File not found: {file_path}")

# Convert features and labels to numpy arrays
X_audio = np.array(features)
y_audio = np.array(labels)

# Ensure data is available for training
if len(X_audio) == 0:
    exit("No features extracted. Ensure valid audio files are present.")

print(f"Extracted features: {X_audio.shape}, Labels: {len(y_audio)}")

# Split the data
X_train_audio, X_test_audio, y_train_audio, y_test_audio = train_test_split(
    X_audio, y_audio, test_size=0.2, random_state=42
)

# Train the model
audio_model = RandomForestClassifier(n_estimators=100, random_state=42)
audio_model.fit(X_train_audio, y_train_audio)

# Evaluate the model
y_pred_audio = audio_model.predict(X_test_audio)
print("Audio Classification Report:\n", classification_report(y_test_audio, y_pred_audio))
print("Accuracy:", accuracy_score(y_test_audio, y_pred_audio))


# Function to predict audio sentiment
def predict_audio_sentiment(file_path, model):
    try:
        mfcc = extract_mfcc_features(file_path)
        if mfcc is not None:
            return model.predict([mfcc])[0]
        return "Error: Features could not be extracted"
    except Exception as e:
        print(f"Error during prediction: {e}")
        return "Error processing file"

# Example usage of audio prediction
# Specify a file you want to predict
example_audio_file = r"C:\Users\growt\Desktop\ML\Test.wav"  # Replace with an actual file path
if os.path.exists(example_audio_file):
    prediction = predict_audio_sentiment(example_audio_file, audio_model)
    print(f"Prediction for {example_audio_file}: {prediction}")
else:
    print(f"Example audio file does not exist: {example_audio_file}")